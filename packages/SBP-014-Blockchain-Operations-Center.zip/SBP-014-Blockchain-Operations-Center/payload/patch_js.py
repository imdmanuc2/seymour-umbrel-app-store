from pathlib import Path
p=Path("seymour-blockchain-manager/data/web/app.js");t=p.read_text()
if 'data-operations="${provider.providerId}"' not in t:
 m='data-adopt="${provider.providerId}"';pos=t.find(m)
 if pos==-1: raise SystemExit("Could not locate Adopt button.")
 start=t.rfind("<button",0,pos);line=t.rfind("\n",0,start)+1;indent=t[line:start]
 button=f'{indent}<button\n{indent}  class="secondary"\n{indent}  data-operations="${{provider.providerId}}"\n{indent}>\n{indent}  Operations\n{indent}</button>\n'
 t=t[:start]+button+t[start:]
if 'querySelectorAll("[data-operations]")' not in t:
 m='grid.querySelectorAll("[data-adopt]")';pos=t.find(m)
 if pos==-1: raise SystemExit("Could not locate Adopt binding.")
 line=t.rfind("\n",0,pos)+1;indent=t[line:pos]
 bind=f'{indent}grid.querySelectorAll("[data-operations]").forEach((button) => {{\n{indent}  button.addEventListener("click", () => {{\n{indent}    showOperationsCenter(button.dataset.operations);\n{indent}  }});\n{indent}}});\n\n'
 t=t[:line]+bind+t[line:]
p.write_text(t);print("Blockchain Operations Center UI action added.")
