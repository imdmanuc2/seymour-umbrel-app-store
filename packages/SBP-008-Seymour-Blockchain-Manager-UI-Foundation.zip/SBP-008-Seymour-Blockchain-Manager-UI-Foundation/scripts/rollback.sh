#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-/home/umbrel/seymour-umbrel-app-store-git}"
BACKUP="${2:-}"

[[ -d "$BACKUP" ]] || {
  echo "Invalid backup: $BACKUP" >&2
  exit 1
}

rm -rf "$REPO/seymour-blockchain-manager"

if [[ -d "$BACKUP/seymour-blockchain-manager" ]]; then
  cp -a \
    "$BACKUP/seymour-blockchain-manager" \
    "$REPO/"
fi

rm -f \
  "$REPO/tests/test_blockchain_manager_ui.py" \
  "$REPO/tests/test_blockchain_manager_catalog.py"

echo "SBP-008 rollback: PASS"
