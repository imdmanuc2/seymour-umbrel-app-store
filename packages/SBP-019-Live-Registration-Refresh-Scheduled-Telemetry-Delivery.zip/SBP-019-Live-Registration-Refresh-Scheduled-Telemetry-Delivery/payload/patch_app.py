from pathlib import Path
p=Path("seymour-blockchain-manager/data/web/app.py"); t=p.read_text()
anchor="from nexus_delivery import deliver, load_status\n"
imp="from nexus_scheduler import refresh_once as nexus_refresh_once, start as start_nexus_scheduler, status as nexus_scheduler_status\n"
if imp not in t:
    if anchor not in t: raise SystemExit("Could not locate nexus_delivery import")
    t=t.replace(anchor,anchor+imp,1)
if '/api/nexus/scheduler/status' not in t:
    a='        if self.path == "/api/nexus/delivery/status":\n'
    r='        if self.path == "/api/nexus/scheduler/status":\n            self.send_json(nexus_scheduler_status())\n            return\n\n'
    if a not in t: raise SystemExit("Could not locate delivery status route")
    t=t.replace(a,r+a,1)
if '/api/nexus/scheduler/run' not in t:
    a='        if self.path == "/api/nexus/delivery":\n'
    r='        if self.path == "/api/nexus/scheduler/run":\n            result = nexus_refresh_once()\n            status = HTTPStatus.OK if result.get("status") in {"succeeded","disabled","not-configured"} else HTTPStatus.BAD_GATEWAY\n            self.send_json(result, status=status)\n            return\n\n'
    if a not in t: raise SystemExit("Could not locate delivery POST route")
    t=t.replace(a,r+a,1)
if 'start_nexus_scheduler()' not in t:
    candidates=['    server.serve_forever()','    httpd.serve_forever()']
    marker=next((x for x in candidates if x in t),None)
    if marker is None: raise SystemExit("Could not locate serve_forever startup")
    t=t.replace(marker,'    start_nexus_scheduler()\n'+marker,1)
p.write_text(t); print("Nexus scheduler application integration added.")
