from pathlib import Path
path = Path("seymour-blockchain-manager/data/web/app.js")
text = path.read_text()
if 'data-sync="${provider.providerId}"' not in text:
    anchor = '''          ${
            provider.selectable
              ? `
                <button
                  class="primary"
                  data-manage="${provider.providerId}"
                >
                  Manage
                </button>
              `
'''
    replacement = '''          ${
            provider.selectable
              ? `
                <button
                  class="secondary"
                  data-sync="${provider.providerId}"
                >
                  Sync
                </button>
                <button
                  class="primary"
                  data-manage="${provider.providerId}"
                >
                  Manage
                </button>
              `
'''
    if anchor not in text:
        raise SystemExit("Expected provider action block not found.")
    text = text.replace(anchor, replacement, 1)
    bind_anchor = '''  grid.querySelectorAll("[data-manage]").forEach((button) => {
'''
    bind_code = '''  grid.querySelectorAll("[data-sync]").forEach((button) => {
    button.addEventListener("click", () => {
      showSyncManager(button.dataset.sync);
    });
  });

'''
    if bind_anchor not in text:
        raise SystemExit("Expected manage binding block not found.")
    text = text.replace(bind_anchor, bind_code + bind_anchor, 1)
path.write_text(text)
print("Sync Manager UI action added.")
